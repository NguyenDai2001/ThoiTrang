<?php

    file_put_contents('kakak.txt', 'xsss');
?>