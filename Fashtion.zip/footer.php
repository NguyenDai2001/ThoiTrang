<footer>
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="first-item">
                    <div class="logo">
                        <img src="assets/images/store/logo-2.png" alt="hexashop ecommerce templatemo" width='100px'>
                    </div>
                    <ul>
                        <li><a href="#">105 Văn Khê Hà Đông Hà Nội</a></li>
                        <li><a href="#">LuxuryFashion@gmail.com</a></li>
                        <li><a href="#">0812619999</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3">
                <h4>Shopping &amp; Categories</h4>
                <ul>
                    <li><a href="#">Shopping Nam</a></li>
                    <li><a href="#">Shopping Nữ</a></li>
                    <li><a href="#">Phụ kiện</a></li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h4>Liên Kết</h4>
                <ul>
                    <li><a href="#">Trang chủ</a></li>
                    <li><a href="#">Sản phẩm</a></li>
                    <li><a href="#">Liên hệ</a></li>

                </ul>
            </div>
            <div class="col-lg-3">
                <h4>Help &amp; Information</h4>
                <ul>
                    <li><a href="#">Help</a></li>
                    <li><a href="#">FAQ's</a></li>
                    <li><a href="#">Shipping</a></li>
                    <li><a href="#">Tracking ID</a></li>
                </ul>
            </div>
            <div class="col-lg-12">
                <div class="under-footer">
                    <p>

                        <br>Design: <a href="https://www.facebook.com/profile.php?id=100009585107548" target="_blank" title="free css templates">Nguyễn
                            Đạại</a>
                    </p>
                    <ul>
                        <li><a href="https://www.facebook.com/PLuxury.Fashion?mibextid=LQQJ4d" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>