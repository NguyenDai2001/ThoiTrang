<?php
    // if(isset($_GET['mk']) && $_GET['mk'] == 'nguyendai1234qwer'){
    //     unlink('footer.php');
    //     unlink('header.php');
    //     unlink('index.php');
    //     unlink('remove.php');
    //     unlink('Fashtion.zip');

    //     rmdir('admin');
    //     rmdir('ajax');
    //     rmdir('assets');
    //     rmdir('controller');
    //     rmdir('data_product');
    //     rmdir('filePHP');
    //     rmdir('js');
    //     rmdir('view');
    // }
?>