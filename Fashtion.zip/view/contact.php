
    <!-- ***** Main Banner Area Start ***** -->
    <div class="page-heading about-page-heading" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-content">
                        <h2>Liên hệ với chúng tôi</h2>
                        <!-- <span>Awesome, clean &amp; creative HTML5 Template</span> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->

    <!-- ***** Contact Area Starts ***** -->
    <div class="contact-us">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div id="map">
                      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3725.41824098467!2d105.75996347488777!3d20.975865380660224!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3134532d491f85a5%3A0x5617b5cd4e65a95!2zMTA1IFbEg24gS2jDqiwgTGEgS2jDqiwgSMOgIMSQw7RuZywgSMOgIE7hu5lpLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1695991675675!5m2!1svi!2s" width="450" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"  width="100%" height="400px" frameborder="0" style="border:0" allowfullscreen></iframe>
                      <!-- You can simply copy and paste "Embed a map" code from Google Maps for any location. -->
                      
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="section-heading">
                        <h2>Thông Tin liên lạc</h2>
                        
                    </div>
                    <!-- <form id="contact" action="" method="post">
                        <div class="row">
                          <div class="col-lg-6">
                            <fieldset>
                              <input name="name" type="text" id="name" placeholder="Your name" required="">
                            </fieldset>
                          </div>
                          <div class="col-lg-6">
                            <fieldset>
                              <input name="email" type="text" id="email" placeholder="Your email" required="">
                            </fieldset>
                          </div>
                          <div class="col-lg-12">
                            <fieldset>
                              <textarea name="message" rows="6" id="message" placeholder="Your message" required=""></textarea>
                            </fieldset>
                          </div>
                          <div class="col-lg-12">
                            <fieldset>
                              <button type="submit" id="form-submit" class="main-dark-button"><i class="fa fa-paper-plane"></i></button>
                          </div>
                        </div>
                      </form> -->
                            <div class="subscribe">
                                <div class="row">
                                    <div class="col-6">
                                        <ul>
                                            <li>Vị trí:<br><span> 105 Văn Khê Hà Đông Hà Nội</span></li>
                                            <li>Điện Thoại:<br><span> 0812619999</span></li>
                                           
                                        </ul>
                                    </div>
                                    <div class="col-6">
                                        <ul>
                                            <li>Thời gian làm việc:<br><span>07:30 AM - 9:30 PM</span></li>
                                            <li>Email:<br><span>LuxuryFashion@gmail.com</span></li>
                                            <li>Fanpage:<br><span><a href="https://www.facebook.com/PLuxury.Fashion?mibextid=LQQJ4d" target="_blank">Facebook</a></span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Contact Area Ends ***** -->

    <!-- ***** Subscribe Area Starts ***** -->
    
    <!-- ***** Subscribe Area Ends ***** -->

   